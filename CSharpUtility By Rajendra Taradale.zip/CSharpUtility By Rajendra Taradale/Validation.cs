﻿using System;
using System.Text.RegularExpressions;

namespace ValidationUtility
{
    /// <summary>
    /// Rajendra Taradale
    /// </summary>
    public static class Validation
    {
        /// <summary>
        /// RT:It will validate email format
        /// </summary>
        /// <param name="inputemail"></param>
        /// <returns></returns>
        public static bool CustomEmailValidate(string inputemail)
        {
            return Regex.IsMatch(inputemail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
        }

        /// <summary>
        /// RT:It will validate Visa Card Number
        /// </summary>
        /// <param name="ccno"></param>
        /// <returns></returns>
        public static bool CustomVisaCCValidate(string ccno)
        {
            return Regex.Match(ccno, @"^4[0-9]{12}(?:[0-9]{3})$").Success;
        }

        /// <summary>
        /// RT:It will validate MasterCard CC Numder
        /// </summary>
        /// <param name="ccno"></param>
        /// <returns></returns>
        public static bool CustomMasterCardCCValidate(string ccno)
        {
            return Regex.Match(ccno, @"^5[0-9]{12}(?:[0-9]{3})$").Success;
        }

        /// <summary>
        /// RT:It will validate 10 digit phone number
        /// </summary>
        /// <param name="phonenumber"></param>
        /// <returns></returns>
        public static bool CustomPhoneValidate(string phonenumber)
        {
            return Regex.Match(phonenumber, @"^[0-9]{10}$").Success;
        }

        /// <summary>
        /// RT:It will remove the characters from string
        /// </summary>
        /// <param name="phone"></param>
        /// <returns></returns>
        public static string RemoveNonNumeric(this string phone)
        {
            return Regex.Replace(phone, @"[^0-9]+", "");
        }

        /// <summary>
        /// RT:It will validate Date format 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static bool CustomDateValidate(string date)
        {
            return DateTime.TryParse(date, out DateTime dt);
        }
    }
}
